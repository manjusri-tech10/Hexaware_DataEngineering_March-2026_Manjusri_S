# Healthcare Appointment Management Platform

A Flask-based REST API for managing healthcare appointments, doctor availability, and service health monitoring.

## 📁 Project Structure

```
healthcare-appointment-platform/
├── app.py                          # Main Flask application
├── test_app.py                     # Pytest test suite
├── requirements.txt                # Python dependencies
├── .gitignore                      # Git ignore rules
├── README.md                       # Project documentation
└── .github/
    └── workflows/
        └── python-app.yml          # GitHub Actions CI pipeline
```

## 🚀 API Endpoints

| Endpoint              | Method | Description                        |
|-----------------------|--------|------------------------------------|
| `/`                   | GET    | Platform home / welcome message    |
| `/health`             | GET    | Appointment service health check   |
| `/appointment-status` | GET    | Patient appointment status         |
| `/doctor-availability`| GET    | Doctor availability status         |

## ⚙️ Local Setup & Running

### Prerequisites
- Python 3.10+
- pip

### Steps

```bash
# 1. Clone the repository
git clone https://github.com/<your-username>/healthcare-appointment-platform.git
cd healthcare-appointment-platform

# 2. (Optional) Create a virtual environment
python -m venv venv
source venv/bin/activate        # macOS/Linux
venv\Scripts\activate           # Windows

# 3. Install dependencies
pip install -r requirements.txt

# 4. Run the Flask app
python app.py
```

The app will start on `http://127.0.0.1:5000`

## 🧪 Running Tests Locally

```bash
pytest
```

Expected output:
```
collected 4 items

test_app.py ....                                         [100%]

4 passed in Xs
```

## 🔄 CI/CD Pipeline (GitHub Actions)

The pipeline triggers automatically on every push to the `main` branch.

### Pipeline Steps:
1. **Checkout Code** — pulls latest code from the repo
2. **Set Up Python 3.10** — configures the Python environment
3. **Install Dependencies** — runs `pip install -r requirements.txt`
4. **Run Tests** — executes `pytest` and validates all tests pass

### View Pipeline Results:
Go to your GitHub repo → **Actions** tab → click the latest workflow run.

## 📋 Trello Board Structure

Organize your Trello board with these lists:

| List        | Purpose                              |
|-------------|--------------------------------------|
| Backlog     | All upcoming work items              |
| Features    | High-level features from the Epic    |
| User Stories| User-focused story breakdowns        |
| Tasks       | Developer-level implementation tasks |
| In Progress | Actively being worked on             |
| Completed   | Done and verified items              |

### Epic → Feature → Story → Task Breakdown

**Epic:** Build and Automate CI Workflow for Healthcare Appointment Management Platform

**Features & Stories:**

- **Feature 1: Appointment API Development**
  - Story: As a patient, I can check my appointment status via API
    - Task: Implement `/appointment-status` endpoint
    - Task: Write unit test for appointment status

- **Feature 2: Doctor Availability Tracking**
  - Story: As a patient, I can check doctor availability via API
    - Task: Implement `/doctor-availability` endpoint
    - Task: Write unit test for doctor availability

- **Feature 3: Application Monitoring**
  - Story: As an ops engineer, I can check service health via API
    - Task: Implement `/health` endpoint
    - Task: Write unit test for health check

- **Feature 4: Repository Management**
  - Story: As a developer, I can track code changes in GitHub
    - Task: Create GitHub repository
    - Task: Push code with proper commit messages
    - Task: Add `.gitignore` and `README.md`

- **Feature 5: CI Pipeline Setup**
  - Story: As a developer, I can validate every push automatically
    - Task: Create `.github/workflows/python-app.yml`
    - Task: Configure Python setup step
    - Task: Configure test execution step
    - Task: Verify pipeline passes on push to main
