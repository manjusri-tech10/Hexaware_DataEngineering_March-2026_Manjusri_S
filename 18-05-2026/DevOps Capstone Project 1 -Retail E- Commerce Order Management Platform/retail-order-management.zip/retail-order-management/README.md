# Retail E-Commerce Order Management Platform

A DevOps Capstone Project demonstrating CI/CD automation using GitHub Actions, Flask, and pytest.

## Project Structure

```
retail-order-management/
├── app.py                          # Flask application
├── requirements.txt                # Python dependencies
├── test_app.py                     # Pytest unit tests
├── README.md                       # Project documentation
└── .github/
    └── workflows/
        └── python-app.yml          # GitHub Actions CI workflow
```

## API Endpoints

| Endpoint        | Description                        |
|-----------------|------------------------------------|
| `/`             | Home — Platform name               |
| `/health`       | Health check — Service status      |
| `/order-status` | Order processing status            |
| `/inventory`    | Inventory availability             |

## How to Run Locally

### 1. Clone the repository
```bash
git clone https://github.com/<your-username>/retail-order-management.git
cd retail-order-management
```

### 2. Install dependencies
```bash
pip install -r requirements.txt
```

### 3. Run the Flask app
```bash
python app.py
```

### 4. Run tests
```bash
pytest
```

## CI/CD Pipeline

The GitHub Actions workflow (`.github/workflows/python-app.yml`) automatically:
- Triggers on every push to `main`
- Sets up Python 3.10
- Installs all dependencies
- Runs all pytest unit tests
- Validates build success

## How to Push to GitHub

```bash
git init
git add .
git commit -m "Initial commit: Retail Order Management Platform"
git remote add origin https://github.com/<your-username>/retail-order-management.git
git branch -M main
git push -u origin main
```

## Tech Stack

- **Language:** Python 3.10
- **Framework:** Flask
- **Testing:** pytest
- **CI/CD:** GitHub Actions
- **Agile Planning:** Trello
